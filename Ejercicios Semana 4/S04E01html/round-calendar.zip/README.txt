A Pen created at CodePen.io. You can find this one at https://codepen.io/anon/pen/gvMoJR.

 View it at <a href="http://drbl.in/iXyX">dribbble</a> or <a href="http://bit.ly/1bzlsRH">Behance</a><br>
<a href="http://drbl.in/iXyX">Download .psd</a>