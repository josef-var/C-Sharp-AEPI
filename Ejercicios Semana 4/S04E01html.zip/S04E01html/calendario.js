document.getElementById("Back").addEventListener("click", goBack);

function goBack(){
    window.history.back();
}
