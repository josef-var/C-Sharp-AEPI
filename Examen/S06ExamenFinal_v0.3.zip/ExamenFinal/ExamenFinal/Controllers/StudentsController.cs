﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using ExamenFinal.Models;
using static Microsoft.AspNetCore.Hosting.Internal.HostingApplication;

namespace ExamenFinal.Controllers
{
    public class StudentsController : Controller
    {
        private readonly ExamenFinalContext _context;

        public StudentsController(ExamenFinalContext context)
        {
            _context = context;
        }
        public async Task<IActionResult> Answers()
        {
            return View(await _context.MultChoice.ToListAsync());
        }
        // GET: Students
        public async Task<IActionResult> Index()
        {
            return View(await _context.MultChoice.ToListAsync());
        }
        public async Task<IActionResult> Quiz()
        {
            return View(await _context.MultChoice.ToListAsync());
        }
        [HttpPost]
        public ActionResult CheckAnswer(string AnswerChosen)
        {
            string AnswerLetter = AnswerChosen.Substring(0, 1);
            int QuestionId = int.Parse(AnswerChosen.Substring(1));
            var multChoice = _context.MultChoice.SingleOrDefaultAsync(m => m.Id == QuestionId);
            bool result = true;
            switch (AnswerLetter)
            {
                case "A":
                    result = multChoice.Result.HasTickA;
                    break;
                case "B":
                    result = multChoice.Result.HasTickB;
                    break;
                case "C":
                    result = multChoice.Result.HasTickC;
                    break;
                case "D":
                    result = multChoice.Result.HasTickD;
                    break;
            }
            return Content(result.ToString());
        }


        private bool MultChoiceExists(int id)
        {
            return _context.MultChoice.Any(e => e.Id == id);
        }
    }
}
