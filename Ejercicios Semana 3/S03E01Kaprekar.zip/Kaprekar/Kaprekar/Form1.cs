﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Kaprekar
{
    public partial class Kaprekar : Form
    {
        public Kaprekar()
        {
            InitializeComponent();
        }

        private void GoButton_Click(object sender, EventArgs e)
        {
            var result = chooseNumber.Text;
            resultBox.Text = "Chosen: " + result.ToString() + "\r\n";
            while (int.Parse(result) != 6174)
                {
                var orderedmax = result.OrderByDescending(x => x);
                var orderedmin = result.OrderBy(x => x);
                int max = int.Parse(string.Join("", orderedmax));
                int min = int.Parse(string.Join("", orderedmin));
                if (min == max) break;
                result = (max- min).ToString("D4");
                resultBox.AppendText(max.ToString("D4") + " - " + min.ToString("D4") + " = " + result + "\r\n");
            }
        }
    }
}
