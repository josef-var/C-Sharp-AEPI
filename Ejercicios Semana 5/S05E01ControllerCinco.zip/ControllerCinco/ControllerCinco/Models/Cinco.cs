﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ControllerCinco.Models
{
    public class Cinco
    {
        public int MyNumber { get; set; }
        public int MyResult { get; set; }
    }

}
