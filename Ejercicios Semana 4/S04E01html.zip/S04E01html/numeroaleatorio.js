document.getElementById("Back").addEventListener("click", goBack);
document.getElementById("NewGame").addEventListener("click", NewGame);
document.getElementById("Lesser").addEventListener("click", Lesser);
document.getElementById("Greater").addEventListener("click", Greater);

var tries;
var min;
var max;
var random;

function NewGame() {
    tries = 0;
    min = 1;
    max = 1000;
    random = 500;
    document.getElementById("pcnr").value = random;
    document.getElementById("tries").value = tries;
    document.getElementById("min").innerHTML = min;
    document.getElementById("max").innerHTML = max;
}

function getRandomInt(min, max) {
    console.log(min + "-" + max + "-" + (max-min));
    return Math.floor(Math.random() * (max - min + 1)) + min;
    //return Math.floor((Math.random() * max) + min);
}



function Lesser() {
    tries++;
    document.getElementById("tries").value = tries;

    max = document.getElementById("pcnr").value;
    //min = document.getElementById("min").innerHTML
    console.log(min + "-" + max);
    random = getRandomInt(min, max);;
    document.getElementById("pcnr").value = random;
    document.getElementById("min").innerHTML = min;
    document.getElementById("max").innerHTML = max;
}
function Greater() {
    tries++;
    document.getElementById("tries").value = tries;

    min = document.getElementById("pcnr").value;
    //max = document.getElementById("max").innerHTML;
    console.log(min + "-" + max);
    random = getRandomInt(min, max);
    document.getElementById("pcnr").value = random;
    document.getElementById("min").innerHTML = min;
    document.getElementById("max").innerHTML = max;
}
function goBack() {
    window.history.back();
}
